##
## Comparative example based on Yan and Kang (GGE biplot analysis)
##

oask <- devAskNewPage(dev.interactive(orNone=TRUE))

bp <- bpca(t(gge2003),
           var.rb=TRUE)

as.dist(bp$var.rb)

op <- par(no.readonly=TRUE)

par(mfrow=c(1,2))

plot(bpca(gge2003),
     main='Columns as variables',
     var.color=1,
     obj.col=2:4,
     obj.cex=.8)

plot(bpca(t(gge2003)),
     main='Rows as variables',
     var.color=1,
     obj.col=c(2:4, 2),
     obj.cex=.8)

par(op)

devAskNewPage(oask)

